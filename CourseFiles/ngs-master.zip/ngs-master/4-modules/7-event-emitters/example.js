const EventEmitter = require('events');

// Streams are Event Emitters
// process.stdin, process.stdout
