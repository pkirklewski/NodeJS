// Top-level API is an array

module.exports = [2, 3, 5, 7];
