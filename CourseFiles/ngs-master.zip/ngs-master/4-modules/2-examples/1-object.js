// Top-level API is a simple object (no need to use module.exports)

exports.language = 'English';

exports.direction = 'RTL';

exports.encoding = 'UTF-8';
