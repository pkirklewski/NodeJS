console.log(require('./2-array'));
