console.log('Who needs the Event Loop!!');
