setInterval(() => {
  console.log('Hello Event Loop!!');
}, 5000);
