const print = require('frame-print');

print('Hello NPM!');

/*
Expected Output:

**********
Hello NPM!
**********
*/
